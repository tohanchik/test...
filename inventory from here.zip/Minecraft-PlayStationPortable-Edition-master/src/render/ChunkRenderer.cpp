// ChunkRenderer.cpp
#include "ChunkRenderer.h"
#include "../math/Frustum.h"
#include "PSPRenderer.h"
#include "Tesselator.h"
#include "TileRenderer.h"
#include <malloc.h>
#include <pspgu.h>
#include <pspgum.h>
#include <pspkernel.h>
#include <string.h>

#define MAX_VERTS_PER_SUB_CHUNK 8000

static CraftPSPVertex g_opaqueBuf[SUBCHUNK_COUNT][MAX_VERTS_PER_SUB_CHUNK];
static CraftPSPVertex g_transBuf[SUBCHUNK_COUNT][MAX_VERTS_PER_SUB_CHUNK];
static CraftPSPVertex g_transFancyBuf[SUBCHUNK_COUNT][MAX_VERTS_PER_SUB_CHUNK];
static CraftPSPVertex g_emitBuf[SUBCHUNK_COUNT][MAX_VERTS_PER_SUB_CHUNK];

static bool uploadMeshSafe(CraftPSPVertex *&dst, int &dstCount, int &dstCap,
                           int newCount, int growPad, CraftPSPVertex *src) {
  if (newCount <= 0) {
    if (dst) {
      free(dst);
      dst = nullptr;
    }
    dstCap = 0;
    dstCount = 0;
    return true;
  }

  CraftPSPVertex *target = dst;
  int targetCap = dstCap;
  if (newCount > targetCap) {
    int nextCap = newCount + growPad;
    CraftPSPVertex *newBuf = (CraftPSPVertex *)memalign(16, nextCap * sizeof(CraftPSPVertex));
    if (!newBuf) {
      // Low-memory fallback: keep existing buffer and upload a truncated mesh
      // rather than leaving the chunk permanently invisible/dirty.
      if (target && targetCap > 0) {
        int clamped = targetCap;
        memcpy(target, src, clamped * sizeof(CraftPSPVertex));
        sceKernelDcacheWritebackInvalidateRange(target,
                                                clamped * sizeof(CraftPSPVertex));
        dst = target;
        dstCap = targetCap;
        dstCount = clamped;
        return true;
      }
      // No existing mesh yet: try progressively smaller allocations and upload
      // a reduced mesh so the chunk still renders instead of disappearing.
      int fallbackCap = (newCount / 2) - ((newCount / 2) % 3);
      while (!newBuf && fallbackCap >= 256) {
        newBuf = (CraftPSPVertex *)memalign(16, fallbackCap * sizeof(CraftPSPVertex));
        if (!newBuf) {
          fallbackCap /= 2;
          fallbackCap -= (fallbackCap % 3);
        }
      }
      if (newBuf && fallbackCap > 0) {
        memcpy(newBuf, src, fallbackCap * sizeof(CraftPSPVertex));
        sceKernelDcacheWritebackInvalidateRange(newBuf,
                                                fallbackCap * sizeof(CraftPSPVertex));
        dst = newBuf;
        dstCap = fallbackCap;
        dstCount = fallbackCap;
        return true;
      }
      // Still out of memory: report failure so caller keeps the subchunk dirty
      // and retries compilation/upload later.
      dstCount = 0;
      return false;
    }
    if (dst) free(dst);
    target = newBuf;
    targetCap = nextCap;
  }

  memcpy(target, src, newCount * sizeof(CraftPSPVertex));
  sceKernelDcacheWritebackInvalidateRange(target, newCount * sizeof(CraftPSPVertex));

  // If geometry density dropped significantly, shrink the resident mesh buffer
  // to reduce long-run fragmentation and peak RAM usage on PSP.
  if (target && targetCap > newCount * 2) {
    int shrinkCap = newCount + growPad;
    CraftPSPVertex *shrunk =
        (CraftPSPVertex *)memalign(16, shrinkCap * sizeof(CraftPSPVertex));
    if (shrunk) {
      memcpy(shrunk, target, newCount * sizeof(CraftPSPVertex));
      sceKernelDcacheWritebackInvalidateRange(shrunk,
                                              newCount * sizeof(CraftPSPVertex));
      if (target != dst) free(target);
      if (dst) free(dst);
      target = shrunk;
      targetCap = shrinkCap;
    }
  }

  dst = target;
  dstCap = targetCap;
  dstCount = newCount;
  return true;
}

ChunkRenderer::ChunkRenderer(TextureAtlas *atlas)
    : m_level(nullptr), m_atlas(atlas), m_compileStep(0), m_compileChunk(nullptr), m_compileSy(-1) {}

ChunkRenderer::~ChunkRenderer() {}

void ChunkRenderer::setLevel(Level *level) { m_level = level; }

#include <psprtc.h>

void ChunkRenderer::processCompileQueue(float camX, float camY, float camZ) {
  if (!m_level)
    return;

  // Limit compile time
  uint64_t tickStart;
  sceRtcGetCurrentTick(&tickStart);
  uint32_t tickRes = sceRtcGetTickResolution();
  
  while (true) {
    uint64_t currentTick;
    sceRtcGetCurrentTick(&currentTick);
    float elapsedMs = (float)(currentTick - tickStart) / ((float)tickRes / 1000.0f);
    if (elapsedMs > 4.0f) {
      break;
    }

  if (m_compileStep == 0) {
    // Find closest dirty subchunk
    Chunk *closestDirty = nullptr;
    int closestDirtySy = -1;
    float closestDirtyDistSq = 9999999.0f;

    for (int cx = 0; cx < WORLD_CHUNKS_X; cx++) {
      for (int cz = 0; cz < WORLD_CHUNKS_Z; cz++) {
        Chunk *c = m_level->getChunk(cx, cz);
        if (c) {
          for (int sy = 0; sy < SUBCHUNK_COUNT; sy++) {
            if (c->dirty[sy]) {
              float chunkCenterX = c->cx * CHUNK_SIZE_X + CHUNK_SIZE_X / 2.0f;
              float chunkCenterZ = c->cz * CHUNK_SIZE_Z + CHUNK_SIZE_Z / 2.0f;
              float chunkCenterY = sy * 16 + 8.0f;
              float dx = chunkCenterX - camX;
              float dy = chunkCenterY - camY;
              float dz = chunkCenterZ - camZ;
              float distSq = dx * dx + dy * dy + dz * dz;
              if (distSq < closestDirtyDistSq) {
                closestDirtyDistSq = distSq;
                closestDirty = c;
                closestDirtySy = sy;
              }
            }
          }
        }
      }
    }

    if (closestDirty) {
      m_compileChunk = closestDirty;
      m_compileSy = closestDirtySy;
      m_compileStep = 1;
      m_opaqueTess.begin(g_opaqueBuf[m_compileSy], MAX_VERTS_PER_SUB_CHUNK);
      m_transTess.begin(g_transBuf[m_compileSy], MAX_VERTS_PER_SUB_CHUNK);
      m_transFancyTess.begin(g_transFancyBuf[m_compileSy], MAX_VERTS_PER_SUB_CHUNK);
      m_emitTess.begin(g_emitBuf[m_compileSy], MAX_VERTS_PER_SUB_CHUNK);
    }
  }

  if (m_compileStep == 1) {
    // Compile y-layers
    int yStart = m_compileSy * 16;
    int yEnd = yStart + 16;

    TileRenderer tileRenderer(m_level, &m_opaqueTess, &m_transTess, &m_transFancyTess, &m_emitTess);
    for (int lx = 0; lx < CHUNK_SIZE_X; lx++) {
      for (int lz = 0; lz < CHUNK_SIZE_Z; lz++) {
        for (int ly = yStart; ly < yEnd; ly++) {
          uint8_t id = m_compileChunk->blocks[lx][lz][ly];
          if (id == BLOCK_AIR)
            continue;

          const BlockProps &bp = g_blockProps[id];
          if (!bp.isSolid() && !bp.isTransparent() && !bp.isLiquid())
            continue;

          tileRenderer.tesselateBlockInWorld(id, lx, ly, lz, m_compileChunk->cx, m_compileChunk->cz);
        }
      }
    }
    
    // Upload immediately
    Chunk* c = m_compileChunk;
    int sy = m_compileSy;

    int newOpaque = m_opaqueTess.end();
    int newTrans = m_transTess.end();
    int newFancy = m_transFancyTess.end();
    int newEmit = m_emitTess.end();
    bool ok = true;
    ok &= uploadMeshSafe(c->opaqueVertices[sy], c->opaqueTriCount[sy], c->opaqueCapacity[sy], newOpaque, 250, g_opaqueBuf[sy]);
    ok &= uploadMeshSafe(c->transVertices[sy], c->transTriCount[sy], c->transCapacity[sy], newTrans, 250, g_transBuf[sy]);
    ok &= uploadMeshSafe(c->transFancyVertices[sy], c->transFancyTriCount[sy], c->transFancyCapacity[sy], newFancy, 250, g_transFancyBuf[sy]);
    ok &= uploadMeshSafe(c->emitVertices[sy], c->emitTriCount[sy], c->emitCapacity[sy], newEmit, 100, g_emitBuf[sy]);

    c->dirty[sy] = !ok;

    m_compileStep = 0;
    m_compileChunk = nullptr;
  }
  
  // If there are no chunks to compile, exit the while loop early
  if (m_compileStep == 0) {
      break;
  }
  
  } // end while(true)
}

// Finish tessellation and upload vertex data
static void flushSubChunk(Chunk *c, int sy,
                          Tesselator &opT, Tesselator &trT, Tesselator &tfT, Tesselator &emT) {
  int newOpaque = opT.end();
  int newTrans = trT.end();
  int newFancy = tfT.end();
  int newEmit = emT.end();
  bool ok = true;
  ok &= uploadMeshSafe(c->opaqueVertices[sy], c->opaqueTriCount[sy], c->opaqueCapacity[sy], newOpaque, 250, g_opaqueBuf[sy]);
  ok &= uploadMeshSafe(c->transVertices[sy], c->transTriCount[sy], c->transCapacity[sy], newTrans, 250, g_transBuf[sy]);
  ok &= uploadMeshSafe(c->transFancyVertices[sy], c->transFancyTriCount[sy], c->transFancyCapacity[sy], newFancy, 250, g_transFancyBuf[sy]);
  ok &= uploadMeshSafe(c->emitVertices[sy], c->emitTriCount[sy], c->emitCapacity[sy], newEmit, 100, g_emitBuf[sy]);
  c->dirty[sy] = !ok;
}

void ChunkRenderer::rebuildChunkNow(int cx, int cz, int sy) {
  if (!m_level) return;
  Chunk *c = m_level->getChunk(cx, cz);
  if (!c || sy < 0 || sy >= SUBCHUNK_COUNT) return;

  // Tessellate the full subchunk in one call
  m_opaqueTess.begin(g_opaqueBuf[sy], MAX_VERTS_PER_SUB_CHUNK);
  m_transTess.begin(g_transBuf[sy], MAX_VERTS_PER_SUB_CHUNK);
  m_transFancyTess.begin(g_transFancyBuf[sy], MAX_VERTS_PER_SUB_CHUNK);
  m_emitTess.begin(g_emitBuf[sy], MAX_VERTS_PER_SUB_CHUNK);

  TileRenderer tileRenderer(m_level, &m_opaqueTess, &m_transTess, &m_transFancyTess, &m_emitTess);
  int yStart = sy * 16;
  int yEnd   = yStart + 16;
  for (int lx = 0; lx < CHUNK_SIZE_X; lx++) {
    for (int lz = 0; lz < CHUNK_SIZE_Z; lz++) {
      for (int ly = yStart; ly < yEnd; ly++) {
        uint8_t id = c->blocks[lx][lz][ly];
        if (id == BLOCK_AIR) continue;
        const BlockProps &bp = g_blockProps[id];
        if (!bp.isSolid() && !bp.isTransparent() && !bp.isLiquid()) continue;
        tileRenderer.tesselateBlockInWorld(id, lx, ly, lz, c->cx, c->cz);
      }
    }
  }

  flushSubChunk(c, sy, m_opaqueTess, m_transTess, m_transFancyTess, m_emitTess);
}

void ChunkRenderer::render(float camX, float camY, float camZ) {
  if (!m_level)
    return;

  m_atlas->bind();

  ScePspFMatrix4 vp;
  PSPRenderer_GetViewProjMatrix(&vp);
  Frustum frustum;
  frustum.update(vp);

  static const float RENDER_DISTANCE = 64.0f;
  static const float FANCY_LOD_DIST = 32.0f; 



  struct RenderChunk {
    Chunk *chunk;
    int subChunkIdx;
    float distSq;
    float distSqHoriz;
  };
  RenderChunk visibleChunks[WORLD_CHUNKS_X * WORLD_CHUNKS_Z * SUBCHUNK_COUNT];
  int visibleCount = 0;

  // Process compile queue
  processCompileQueue(camX, camY, camZ);

  // Render loop
  for (int cx = 0; cx < WORLD_CHUNKS_X; cx++) {
    for (int cz = 0; cz < WORLD_CHUNKS_Z; cz++) {
      Chunk *c = m_level->getChunk(cx, cz);
      if (!c)
        continue;

      for (int sy = 0; sy < SUBCHUNK_COUNT; sy++) {
        if ((c->opaqueTriCount[sy] == 0 && c->transTriCount[sy] == 0 &&
             c->transFancyTriCount[sy] == 0 && c->emitTriCount[sy] == 0) ||
            (!c->opaqueVertices[sy] && !c->transVertices[sy] &&
             !c->transFancyVertices[sy] && !c->emitVertices[sy]))
          continue;

        float chunkCenterX = c->cx * CHUNK_SIZE_X + CHUNK_SIZE_X / 2.0f;
        float chunkCenterZ = c->cz * CHUNK_SIZE_Z + CHUNK_SIZE_Z / 2.0f;
        float chunkCenterY = sy * 16 + 8.0f;

        float dx = chunkCenterX - camX;
        float dy = chunkCenterY - camY;
        float dz = chunkCenterZ - camZ;
        
        // Distance culling
        float maxDist = RENDER_DISTANCE + 11.5f;
        float distSqHoriz = dx * dx + dz * dz;
        if (distSqHoriz > maxDist * maxDist)
          continue;

        float distSq = dx * dx + dy * dy + dz * dz;

        AABB box;

        box.x0 = c->cx * CHUNK_SIZE_X - 4.0f;
        box.y0 = sy * 16 - 4.0f;
        box.z0 = c->cz * CHUNK_SIZE_Z - 4.0f;
        box.x1 = c->cx * CHUNK_SIZE_X + CHUNK_SIZE_X + 4.0f;
        box.y1 = sy * 16 + 16 + 4.0f;
        box.z1 = c->cz * CHUNK_SIZE_Z + CHUNK_SIZE_Z + 4.0f;

        // 3D Cubic Frustum Culling
        if (frustum.testAABB(box) == Frustum::OUTSIDE)
          continue;

        visibleChunks[visibleCount].chunk = c;
        visibleChunks[visibleCount].subChunkIdx = sy;
        visibleChunks[visibleCount].distSq = distSq;
        visibleChunks[visibleCount].distSqHoriz = distSqHoriz;
        visibleCount++;
      }
    }
  }

  // Sort visible chunks front-to-back
  for (int i = 0; i < visibleCount - 1; i++) {
    for (int j = 0; j < visibleCount - i - 1; j++) {
      if (visibleChunks[j].distSq > visibleChunks[j + 1].distSq) {
        RenderChunk temp = visibleChunks[j];
        visibleChunks[j] = visibleChunks[j + 1];
        visibleChunks[j + 1] = temp;
      }
    }
  }

  // Draw opaque chunks

  // Helper: set model matrix to identity (vertices are already in absolute world space)
  auto setChunkMatrix = [](Chunk *c) {
    sceGumMatrixMode(GU_MODEL);
    sceGumLoadIdentity();
    sceGumUpdateMatrix();
  };

  sceGuDisable(GU_ALPHA_TEST);
  sceGuDisable(GU_BLEND);
  // Chunk vertices are already lit in TileRenderer (sky/block light + sun scale).
  // Keep fixed-function lighting off here, otherwise GU ambient flattens contrast
  // and makes the world look uniformly bright.
  sceGuDisable(GU_LIGHTING);

  for (int i = 0; i < visibleCount; i++) {
    Chunk *c = visibleChunks[i].chunk;
    int sy = visibleChunks[i].subChunkIdx;
    if (c->opaqueTriCount[sy] == 0 || !c->opaqueVertices[sy]) continue;
    setChunkMatrix(c);
    sceGumDrawArray(GU_TRIANGLES,
                    GU_TEXTURE_32BITF | GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_3D,
                    c->opaqueTriCount[sy], nullptr, c->opaqueVertices[sy]);
  }

  // Draw emissive chunks
  // Keep alpha test enabled so cutout textures (e.g. leaves/glass in emit-pass)
  // don't render their transparent texels as dark quads.
  sceGuEnable(GU_ALPHA_TEST);
  sceGuAmbient(0xFFFFFFFF);
  for (int i = 0; i < visibleCount; i++) {
    Chunk *c = visibleChunks[i].chunk;
    int sy = visibleChunks[i].subChunkIdx;
    if (c->emitTriCount[sy] == 0 || !c->emitVertices[sy]) continue;
    setChunkMatrix(c);
    sceGumDrawArray(GU_TRIANGLES,
                    GU_TEXTURE_32BITF | GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_3D,
                    c->emitTriCount[sy], nullptr, c->emitVertices[sy]);
  }

  // Draw inner leaves (Back-to-Front check)
  sceGuDisable(GU_LIGHTING);
  sceGuEnable(GU_ALPHA_TEST);
  sceGuEnable(GU_BLEND);
  sceGuDisable(GU_CULL_FACE); // Allow plants/water to be seen from both sides

  for (int i = visibleCount - 1; i >= 0; i--) {
    Chunk *c = visibleChunks[i].chunk;
    int sy = visibleChunks[i].subChunkIdx;
    if (c->transFancyTriCount[sy] == 0 || !c->transFancyVertices[sy]) continue;
    float distSqHoriz = visibleChunks[i].distSqHoriz;
    if (distSqHoriz > FANCY_LOD_DIST * FANCY_LOD_DIST || camY > 128.0f) continue;
    setChunkMatrix(c);
    sceGumDrawArray(GU_TRIANGLES,
                    GU_TEXTURE_32BITF | GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_3D,
                    c->transFancyTriCount[sy], nullptr, c->transFancyVertices[sy]);
  }

  // Draw transparent chunks (Back-to-Front)
  for (int i = visibleCount - 1; i >= 0; i--) {
    Chunk *c = visibleChunks[i].chunk;
    int sy = visibleChunks[i].subChunkIdx;
    if (c->transTriCount[sy] == 0 || !c->transVertices[sy]) continue;
    setChunkMatrix(c);
    sceGumDrawArray(GU_TRIANGLES,
                    GU_TEXTURE_32BITF | GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_3D,
                    c->transTriCount[sy], nullptr, c->transVertices[sy]);
  }

  sceGuEnable(GU_CULL_FACE); // Restore CULL_FACE
  sceGuDisable(GU_LIGHTING); // Restore default state
}
